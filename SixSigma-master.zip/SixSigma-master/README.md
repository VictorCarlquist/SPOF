SixSigma
========

Apresentação sobre o modelo de gerenciamento Six Sigma.